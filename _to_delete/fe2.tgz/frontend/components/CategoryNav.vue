<script setup lang="ts">
import { ui, type MenuCategory, type DrinkGroup } from '~/data/menu'

const props = defineProps<{
  categories: MenuCategory[]
  activeId: string
  activeLevel: string
  activeGroup: DrinkGroup
  search: string
}>()
const emit = defineEmits<{
  select: [id: string]
  'select-level': [id: string]
  'select-group': [id: DrinkGroup]
  'update:search': [value: string]
}>()

const { t } = useLanguage()

// Keep the active chip centered inside the horizontally scrolling nav — scroll
// ONLY the rail, never the window (scrollIntoView would yank the page vertically).
const navRef = ref<HTMLElement | null>(null)
watch(
  () => props.activeId,
  (id) => {
    const rail = navRef.value
    const el = rail?.querySelector<HTMLElement>(`[data-cat="${id}"]`)
    if (!rail || !el) return
    const c = el.getBoundingClientRect()
    const r = rail.getBoundingClientRect()
    rail.scrollTo({ left: rail.scrollLeft + (c.left - r.left) - r.width / 2 + c.width / 2, behavior: 'smooth' })
  },
)
</script>

<template>
  <div data-nav class="sticky top-0 z-30 border-b border-[#D5D1C6] bg-[#F1F0EA]/95 backdrop-blur">
    <div class="mx-auto flex max-w-6xl flex-col gap-2.5 px-4 py-2.5">
      <!-- Level 1: Food / Drinks -->
      <LevelTabs :active-level="activeLevel" @select="emit('select-level', $event)" />

      <!-- Level 2 (Drinks only): Non-Alcoholic / Alcoholic -->
      <GroupTabs
        v-if="activeLevel === 'drinks'"
        :active-group="activeGroup"
        @select="emit('select-group', $event)"
      />

      <!-- Category chips -->
      <nav
        ref="navRef"
        class="-mx-1 flex items-center gap-2 overflow-x-auto px-1 pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
        aria-label="Menu categories"
      >
        <button
          v-for="cat in categories"
          :key="cat.id"
          :data-cat="cat.id"
          type="button"
          class="inline-flex shrink-0 items-center gap-2 rounded-full border px-4 py-2 text-sm font-semibold transition-all duration-200"
          :class="
            activeId === cat.id
              ? 'border-[#64734D] bg-[#64734D] text-white shadow-[0_6px_18px_-6px_rgba(100,115,77,0.45)]'
              : 'border-[#D5D1C6] bg-[#FCFBF7] text-[#292A27] hover:border-[#64734D]/60 hover:bg-[#E2E6D8]'
          "
          @click="emit('select', cat.id)"
        >
          <span v-if="cat.iconImage" class="grid h-5 w-5 shrink-0 place-items-center overflow-hidden rounded-full" aria-hidden="true">
            <img :src="cat.iconImage" alt="" class="h-full w-full object-cover" />
          </span>
          <span v-else class="text-base leading-none" aria-hidden="true">{{ cat.icon }}</span>
          {{ t(cat.title) }}
        </button>
      </nav>

      <!-- Search -->
      <div class="relative">
        <span
          class="pointer-events-none absolute left-1.5 top-1/2 flex h-8 w-8 -translate-y-1/2 items-center justify-center rounded-full bg-[#64734D]/12"
          aria-hidden="true"
        >
          <IconSearch class="h-[18px] w-[18px] text-[#64734D]" />
        </span>
        <input
          :value="search"
          type="search"
          inputmode="search"
          :placeholder="t(ui.searchPlaceholder)"
          class="w-full rounded-full border border-[#D5D1C6] bg-[#FCFBF7] py-3 pl-12 pr-4 font-serif text-base text-[#292A27] placeholder:text-[#95938D] shadow-sm outline-none transition focus:border-[#64734D] focus:ring-2 focus:ring-[#B49A70]/40"
          @input="emit('update:search', ($event.target as HTMLInputElement).value)"
        />
      </div>
    </div>
  </div>
</template>
