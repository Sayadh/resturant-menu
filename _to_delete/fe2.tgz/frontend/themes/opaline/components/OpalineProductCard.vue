<script setup lang="ts">
// ─────────────────────────────────────────────────────────────────────────
// OpalineProductCard — the third level. A porcelain card: a large untinted
// photograph, the dish name in serif, two lines of description, then price
// and the actions on one baseline.
//
// All behaviour comes from the shared stores (useOrderStore for the cart and
// favourites, useBrand for the tenant's plan/cart settings). Nothing here
// duplicates business logic.
// ─────────────────────────────────────────────────────────────────────────
import { ui, badgeLabels, type MenuItem } from '~/data/menu'
import { opalineAdd, opalineQty } from '~/themes/opaline/config'

const props = defineProps<{ item: MenuItem }>()
const emit = defineEmits<{ open: [item: MenuItem] }>()

const { t } = useLanguage()
const order = useOrderStore()
const brand = useBrand() // ordering (cart) = paid plans only

const fmt = (n: number) => n.toLocaleString('hy-AM')
const soldOut = computed(() => props.item.available === false)
const description = computed(() => t(props.item.description).trim())
// `showImage: false` is the admin saying this dish shows NO picture at all --
// so the media block is skipped entirely, placeholder included. When it is on
// but no file was uploaded, the theme's usual placeholder still appears.
const showMedia = computed(() => props.item.showImage !== false)
</script>

<template>
  <article
    class="group flex h-full flex-col overflow-hidden rounded-[18px] border border-[#E2E5E8] bg-[#FFFFFF] shadow-[0_1px_2px_rgba(23,32,51,0.04)] transition duration-300 hover:border-[#CCD1D7] hover:shadow-[0_18px_40px_-26px_rgba(23,32,51,0.26)]"
  >
    <!-- Photograph -->
    <div v-if="showMedia" class="relative">
      <button
        type="button"
        class="block aspect-[4/3] w-full overflow-hidden bg-[#F5F5F2] focus-visible:outline focus-visible:outline-1 focus-visible:outline-offset-[-2px] focus-visible:outline-[#D85F3D]"
        :aria-label="t(item.name)"
        @click="emit('open', item)"
      >
        <img
          v-if="item.image"
          :src="item.image"
          :alt="t(item.name)"
          loading="lazy"
          class="h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.04]"
          :class="{ 'opacity-60': soldOut }"
        />
        <span v-else class="grid h-full w-full place-items-center bg-[#FBEDE8]" aria-hidden="true">
          <svg viewBox="0 0 24 24" class="h-8 w-8 text-[#D85F3D]/55" fill="none" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M4 5v6a3 3 0 0 0 3 3v6M7 5v6M10 5v6M17 5c-1.4 1.6-2 3.6-2 6h4V5z" />
          </svg>
        </span>
      </button>

      <!-- Badge -->
      <span
        v-if="item.badge && !soldOut"
        class="op-label pointer-events-none absolute left-3 top-3 rounded-full bg-[#FFFFFF]/94 px-2.5 py-1 text-[9px] text-[#D85F3D] shadow-[0_2px_8px_rgba(23,32,51,0.10)]"
      >{{ t(badgeLabels[item.badge].text) }}</span>

      <!-- Unavailable -->
      <span
        v-if="soldOut"
        class="op-label pointer-events-none absolute left-3 top-3 rounded-full bg-[#FFFFFF]/94 px-2.5 py-1 text-[9px] text-[#A04F4F] shadow-[0_2px_8px_rgba(23,32,51,0.10)]"
      >{{ t(ui.soldOut) }}</span>

    </div>

    <!-- Copy -->
    <div class="flex flex-1 flex-col p-4 sm:p-5">
      <!-- badge / sold-out kept visible on image-less cards -->
      <div v-if="!showMedia && (item.badge || soldOut)" class="mb-3 flex flex-wrap items-center gap-2">
        <span
          v-if="item.badge && !soldOut"
          class="op-label rounded-full bg-[#FBEDE8] px-2.5 py-1 text-[9px] text-[#D85F3D]"
        >{{ t(badgeLabels[item.badge].text) }}</span>
        <span
          v-if="soldOut"
          class="op-label rounded-full border border-[#E2E5E8] px-2.5 py-1 text-[9px] text-[#A04F4F]"
        >{{ t(ui.soldOut) }}</span>
      </div>

      <div class="mb-4 sm:mb-5">
        <button
          type="button"
          class="op-serif block text-balance text-left text-[19px] leading-snug text-[#172033] transition-colors hover:text-[#D85F3D] focus-visible:outline focus-visible:outline-1 focus-visible:outline-offset-2 focus-visible:outline-[#D85F3D] sm:text-[21px]"
          @click="emit('open', item)"
        >
          {{ t(item.name) }}
        </button>

        <p v-if="description" class="op-sans op-clamp-2 mt-2 text-[13px] leading-relaxed text-[#747D90]">
          {{ description }}
        </p>
      </div>

      <!-- Price + actions — pinned to the bottom so cards in a row line up -->
      <div class="mt-auto flex items-center justify-between gap-3 border-t border-[#E2E5E8] pt-4">
        <p class="op-figure op-serif shrink-0 text-[19px] text-[#172033] sm:text-[21px]">
          {{ fmt(item.price) }}<span class="op-sans ml-1 text-[13px] text-[#A1A6B0]">{{ ui.currency.AM }}</span>
        </p>

        <ClientOnly>
          <template v-if="brand.ordering">
            <div
              v-if="order.qtyOf(item.id) > 0"
              class="flex items-center gap-1 rounded-full border border-[#E2E5E8] p-1"
            >
              <button
                type="button"
                class="grid h-7 w-7 place-items-center rounded-full text-[15px] leading-none text-[#747D90] transition hover:bg-[#F5F5F2] hover:text-[#172033] focus-visible:outline focus-visible:outline-1 focus-visible:outline-offset-1 focus-visible:outline-[#D85F3D]"
                :aria-label="t(opalineQty.less)"
                @click="order.dec(item.id)"
              >−</button>
              <span class="op-figure w-5 text-center text-[13px] font-medium text-[#172033]">{{ order.qtyOf(item.id) }}</span>
              <button
                type="button"
                class="grid h-7 w-7 place-items-center rounded-full bg-[#172033] text-[15px] leading-none text-[#FFFFFF] transition hover:bg-[#222D43] focus-visible:outline focus-visible:outline-1 focus-visible:outline-offset-1 focus-visible:outline-[#D85F3D]"
                :aria-label="t(opalineQty.more)"
                @click="order.add(item.id)"
              >+</button>
            </div>

            <button
              v-else-if="!soldOut"
              type="button"
              class="op-label shrink-0 rounded-full bg-[#172033] px-4 py-2.5 text-[9px] text-[#FFFFFF] transition hover:bg-[#222D43] active:scale-95 focus-visible:outline focus-visible:outline-1 focus-visible:outline-offset-2 focus-visible:outline-[#D85F3D]"
              @click="order.add(item.id)"
            >{{ t(opalineAdd) }}</button>

            <span
              v-else
              class="op-label shrink-0 rounded-full border border-[#E2E5E8] px-3 py-2 text-[9px] text-[#A04F4F]"
            >{{ t(ui.soldOut) }}</span>
          </template>

          <span
            v-else-if="soldOut"
            class="op-label shrink-0 rounded-full border border-[#E2E5E8] px-3 py-2 text-[9px] text-[#A04F4F]"
          >{{ t(ui.soldOut) }}</span>
        </ClientOnly>
      </div>
    </div>
  </article>
</template>
