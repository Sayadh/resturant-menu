// ─────────────────────────────────────────────────────────────────────────
// Blog articles — the core of the SEO content strategy. Each article is a
// data entry rendered by pages/blog/[slug].vue with its own <title>,
// description, canonical and Article JSON-LD.
//
// i18n note: the Armenian fields are the DEFAULT (SSR-rendered) content and
// drive <head> meta + JSON-LD, so SEO keyword targeting stays in `hy`. The
// `i18n.ru` / `i18n.en` blocks provide the VISIBLE translation shown when the
// visitor switches language client-side (see useLandingI18n + localizeArticle).
// ─────────────────────────────────────────────────────────────────────────
export interface BlogBlock { h2?: string; p: string }

export interface BlogContent {
  title: string
  description: string
  excerpt: string
  body: BlogBlock[]
}

export interface BlogArticle extends BlogContent {
  slug: string
  date: string // ISO yyyy-mm-dd
  keyword: string
  published: boolean
  i18n?: { ru: BlogContent; en: BlogContent }
}

export type BlogLang = 'hy' | 'ru' | 'en'

export const blogArticles: BlogArticle[] = [
  {
    slug: 'what-is-qr-menu',
    title: 'Ինչ է QR Menu-ն և ինչպես է այն աշխատում',
    description: 'QR Menu-ն թվային մենյու է, որը հաճախորդը բացում է հեռախոսով՝ QR կոդը սկանավորելով։ Բացատրում ենք ինչ է դա և ինչպես է աշխատում։',
    date: '2026-07-01',
    keyword: 'QR Menu',
    excerpt: 'QR Menu-ն ժամանակակից թվային մենյու է, որը փոխարինում է թղթային մենյուին։ Ահա թե ինչ է դա և ինչպես է աշխատում։',
    body: [
      { p: 'QR Menu-ն ռեստորանի կամ սրճարանի թվային մենյու է, որը հաճախորդը բացում է իր հեռախոսով՝ սեղանի վրա տեղադրված QR կոդը սկանավորելով։ Ոչ մի հավելված ներբեռնելու կարիք չկա — բավական է բացել տեսախցիկը։' },
      { h2: 'Ինչպես է այն աշխատում', p: 'Ռեստորանը ստեղծում է իր թվային մենյուն, ստանում եզակի QR կոդ և տպում այն սեղանների վրա։ Հաճախորդը սկանավորում է կոդը և ակնթարթորեն տեսնում ամբողջ մենյուն՝ լուսանկարներով, գներով և նկարագրություններով։' },
      { h2: 'Ինչու է դա հարմար', p: 'QR Menu-ն միշտ արդիական է․ գնի կամ ապրանքի ցանկացած փոփոխություն երևում է անմիջապես, առանց վերատպելու։ Այն նաև կարող է լինել բազմալեզու՝ հայերեն, ռուսերեն և անգլերեն։' },
    ],
    published: true,
    i18n: {
      ru: {
        title: 'Что такое QR Menu и как оно работает',
        description: 'QR Menu — это цифровое меню, которое гость открывает на телефоне, сканируя QR-код. Объясняем, что это и как работает.',
        excerpt: 'QR Menu — это современное цифровое меню, которое заменяет бумажное. Вот что это такое и как оно работает.',
        body: [
          { p: 'QR Menu — это цифровое меню ресторана или кафе, которое гость открывает на своём телефоне, сканируя QR-код на столе. Никаких приложений скачивать не нужно — достаточно открыть камеру.' },
          { h2: 'Как это работает', p: 'Заведение создаёт своё цифровое меню, получает уникальный QR-код и печатает его для столов. Гость сканирует код и мгновенно видит всё меню — с фото, ценами и описаниями.' },
          { h2: 'Почему это удобно', p: 'QR Menu всегда актуально: любое изменение цены или товара отображается сразу, без перепечатки. Оно также может быть многоязычным — армянский, русский и английский.' },
        ],
      },
      en: {
        title: 'What is a QR Menu and how does it work',
        description: 'A QR Menu is a digital menu the guest opens on their phone by scanning a QR code. We explain what it is and how it works.',
        excerpt: 'A QR Menu is a modern digital menu that replaces the paper one. Here is what it is and how it works.',
        body: [
          { p: 'A QR Menu is a restaurant or café’s digital menu that the guest opens on their phone by scanning a QR code placed on the table. No app to download — just open the camera.' },
          { h2: 'How it works', p: 'The venue creates its digital menu, gets a unique QR code and prints it for the tables. The guest scans the code and instantly sees the full menu — with photos, prices and descriptions.' },
          { h2: 'Why it’s convenient', p: 'A QR Menu is always up to date: any price or item change appears immediately, with no reprinting. It can also be multilingual — Armenian, Russian and English.' },
        ],
      },
    },
  },
  {
    slug: 'qr-menu-vs-paper-menu',
    title: 'Ինչու է QR Menu-ն ավելի լավ, քան թղթային մենյուն',
    description: 'QR Menu vs թղթային մենյու․ ծախս, արագություն, հիգիենա և ճկունություն։ Համեմատում ենք երկուսը։',
    date: '2026-07-02',
    keyword: 'QR Menu',
    excerpt: 'Թղթային մենյուն թանկ է և արագ հնանում։ Ահա 5 պատճառ, թե ինչու QR Menu-ն ավելի լավն է։',
    body: [
      { p: 'Թղթային մենյուն ծանոթ է բոլորին, բայց ունի թերություններ․ վերատպությունը ծախսատար է, փոփոխությունները դանդաղ են, իսկ մենյուն արագ մաշվում է։ QR Menu-ն լուծում է այս բոլորը։' },
      { h2: 'Ծախս', p: 'Ամեն գնի փոփոխության դեպքում թղթային մենյուն պետք է վերատպել։ QR Menu-ն թարմացվում է անվճար մեկ սեղմումով։' },
      { h2: 'Արագություն և ճկունություն', p: 'Վաճառված ապրանքը կարող եք ակնթարթորեն նշել «սպառված», ավելացնել նոր ուտեստներ կամ սեզոնային առաջարկներ՝ առանց ուշացման։' },
      { h2: 'Հիգիենա և փորձառություն', p: 'QR Menu-ն չի անցնում ձեռքից ձեռք, ցույց է տալիս գեղեցիկ լուսանկարներ և բարձրացնում միջին չեկը՝ ախորժալի ներկայացմամբ։' },
    ],
    published: true,
    i18n: {
      ru: {
        title: 'Почему QR Menu лучше бумажного меню',
        description: 'QR Menu против бумажного меню: стоимость, скорость, гигиена и гибкость. Сравниваем оба варианта.',
        excerpt: 'Бумажное меню дорогое и быстро устаревает. Вот 5 причин, почему QR Menu лучше.',
        body: [
          { p: 'Бумажное меню знакомо всем, но у него есть недостатки: перепечатка дорогая, изменения медленные, а само меню быстро изнашивается. QR Menu решает всё это.' },
          { h2: 'Стоимость', p: 'При каждом изменении цены бумажное меню нужно перепечатывать. QR Menu обновляется бесплатно, в один клик.' },
          { h2: 'Скорость и гибкость', p: 'Проданный товар можно мгновенно отметить как «нет в наличии», добавить новые блюда или сезонные предложения — без задержек.' },
          { h2: 'Гигиена и впечатление', p: 'QR Menu не передаётся из рук в руки, показывает красивые фото и повышает средний чек за счёт аппетитной подачи.' },
        ],
      },
      en: {
        title: 'Why a QR Menu is better than a paper menu',
        description: 'QR Menu vs paper menu: cost, speed, hygiene and flexibility. We compare the two.',
        excerpt: 'A paper menu is expensive and quickly outdated. Here are 5 reasons a QR Menu is better.',
        body: [
          { p: 'Everyone knows the paper menu, but it has downsides: reprinting is costly, changes are slow, and the menu wears out fast. A QR Menu solves all of this.' },
          { h2: 'Cost', p: 'Every price change means reprinting a paper menu. A QR Menu updates for free, in one click.' },
          { h2: 'Speed and flexibility', p: 'You can instantly mark a sold-out item as “unavailable”, add new dishes or seasonal offers — with no delay.' },
          { h2: 'Hygiene and experience', p: 'A QR Menu is not passed hand to hand, shows beautiful photos and raises the average check with appetizing presentation.' },
        ],
      },
    },
  },
  {
    slug: 'how-to-create-qr-menu',
    title: 'Ինչպես ստեղծել QR Menu ձեր ռեստորանի համար',
    description: 'Քայլ առ քայլ ուղեցույց՝ ինչպես ստեղծել QR Menu ձեր ռեստորանի կամ սրճարանի համար menus.am-ում։',
    date: '2026-07-03',
    keyword: 'QR Menu',
    excerpt: 'QR Menu ստեղծելը տևում է րոպեներ։ Ահա պարզ քայլերը՝ գրանցումից մինչև տպված QR կոդ։',
    body: [
      { p: 'QR Menu ստեղծելը հեշտ է և չի պահանջում տեխնիկական գիտելիք։ Ահա հիմնական քայլերը menus.am-ում։' },
      { h2: '1. Գրանցվեք և ընտրեք թեմա', p: 'Ստեղծեք հաշիվ և ընտրեք ձեր բրենդին համապատասխան պրեմիում թեմա։' },
      { h2: '2. Ավելացրեք մենյուն', p: 'Ադմին վահանակից ավելացրեք բաժիններ, կատեգորիաներ և ապրանքներ՝ գներով, նկարագրություններով և լուսանկարներով, 3 լեզվով։' },
      { h2: '3. Ստացեք QR կոդը', p: 'Համակարգը ավտոմատ գեներացնում է ձեր QR կոդը։ Տպեք այն և տեղադրեք սեղանների վրա — պատրաստ է։' },
    ],
    published: true,
    i18n: {
      ru: {
        title: 'Как создать QR Menu для вашего ресторана',
        description: 'Пошаговое руководство: как создать QR Menu для вашего ресторана или кафе на menus.am.',
        excerpt: 'Создание QR Menu занимает минуты. Вот простые шаги — от регистрации до напечатанного QR-кода.',
        body: [
          { p: 'Создать QR Menu легко и не требует технических знаний. Вот основные шаги на menus.am.' },
          { h2: '1. Зарегистрируйтесь и выберите тему', p: 'Создайте аккаунт и выберите премиум-тему под ваш бренд.' },
          { h2: '2. Добавьте меню', p: 'В админ-панели добавьте разделы, категории и товары — с ценами, описаниями и фото, на 3 языках.' },
          { h2: '3. Получите QR-код', p: 'Система автоматически генерирует ваш QR-код. Распечатайте его и разместите на столах — готово.' },
        ],
      },
      en: {
        title: 'How to create a QR Menu for your restaurant',
        description: 'A step-by-step guide: how to create a QR Menu for your restaurant or café on menus.am.',
        excerpt: 'Creating a QR Menu takes minutes. Here are the simple steps — from sign-up to a printed QR code.',
        body: [
          { p: 'Creating a QR Menu is easy and requires no technical knowledge. Here are the main steps on menus.am.' },
          { h2: '1. Sign up and choose a theme', p: 'Create an account and pick a premium theme that matches your brand.' },
          { h2: '2. Add your menu', p: 'From the admin panel, add sections, categories and products — with prices, descriptions and photos, in 3 languages.' },
          { h2: '3. Get your QR code', p: 'The system automatically generates your QR code. Print it and place it on the tables — done.' },
        ],
      },
    },
  },
  {
    slug: 'best-qr-menu-platforms',
    title: 'Լավագույն QR Menu համակարգերը',
    description: 'Ինչ չափանիշներով ընտրել QR Menu համակարգ․ բազմալեզու աջակցություն, թեմաներ, կառավարում և գին։',
    date: '2026-07-04',
    keyword: 'QR Menu',
    excerpt: 'Ինչպես ընտրել ճիշտ QR Menu համակարգը ձեր բիզնեսի համար։ Հիմնական չափանիշները։',
    body: [
      { p: 'Շուկայում կան բազմաթիվ QR Menu համակարգեր։ Ահա հիմնական չափանիշները, որոնց վրա արժե ուշադրություն դարձնել ընտրելիս։' },
      { h2: 'Բազմալեզու աջակցություն', p: 'Ձեր մենյուն պետք է հասանելի լինի հայերեն, ռուսերեն և անգլերեն՝ տեղացիների և զբոսաշրջիկների համար։' },
      { h2: 'Հեշտ կառավարում և գին', p: 'Լավ համակարգը թույլ է տալիս ինքնուրույն թարմացնել մենյուն և ունի թափանցիկ գնացուցակ՝ առանց թաքնված վճարների։' },
    ],
    published: true,
    i18n: {
      ru: {
        title: 'Лучшие системы QR Menu',
        description: 'По каким критериям выбрать систему QR Menu: многоязычная поддержка, темы, управление и цена.',
        excerpt: 'Как выбрать правильную систему QR Menu для вашего бизнеса. Основные критерии.',
        body: [
          { p: 'На рынке есть множество систем QR Menu. Вот основные критерии, на которые стоит обратить внимание при выборе.' },
          { h2: 'Многоязычная поддержка', p: 'Ваше меню должно быть доступно на армянском, русском и английском — для местных и туристов.' },
          { h2: 'Простое управление и цена', p: 'Хорошая система позволяет самостоятельно обновлять меню и имеет прозрачные тарифы без скрытых платежей.' },
        ],
      },
      en: {
        title: 'The best QR Menu systems',
        description: 'What criteria to choose a QR Menu system by: multilingual support, themes, management and price.',
        excerpt: 'How to choose the right QR Menu system for your business. The key criteria.',
        body: [
          { p: 'There are many QR Menu systems on the market. Here are the key criteria worth paying attention to when choosing.' },
          { h2: 'Multilingual support', p: 'Your menu should be available in Armenian, Russian and English — for locals and tourists.' },
          { h2: 'Easy management and price', p: 'A good system lets you update the menu yourself and has transparent pricing with no hidden fees.' },
        ],
      },
    },
  },
  {
    slug: 'how-to-update-menu',
    title: 'Ինչպես թարմացնել ռեստորանի մենյուն առցանց',
    description: 'Ինչպես ակնթարթորեն թարմացնել ձեր ռեստորանի մենյուն առցանց՝ գներ, ապրանքներ, հասանելիություն։',
    date: '2026-07-05',
    keyword: 'Online Menu',
    excerpt: 'Առցանց մենյուն թարմացվում է վայրկյանների ընթացքում։ Ահա ինչպես։',
    body: [
      { p: 'Թվային մենյուի ամենամեծ առավելություններից մեկը ակնթարթային թարմացումն է։ Ահա ինչպես դա անել առցանց։' },
      { h2: 'Գների և ապրանքների փոփոխություն', p: 'Ադմին վահանակից բացեք ապրանքը, փոխեք գինը կամ նկարագրությունը և պահեք — փոփոխությունը երևում է անմիջապես բոլոր հաճախորդների մոտ։' },
      { h2: 'Հասանելիության կառավարում', p: 'Վաճառված ուտեստը նշեք «սպառված»՝ մեկ սեղմումով, և հաճախորդները չեն պատվիրի այն։' },
    ],
    published: true,
    i18n: {
      ru: {
        title: 'Как обновить меню ресторана онлайн',
        description: 'Как мгновенно обновить меню вашего ресторана онлайн: цены, товары, наличие.',
        excerpt: 'Онлайн-меню обновляется за секунды. Вот как.',
        body: [
          { p: 'Одно из главных преимуществ цифрового меню — мгновенное обновление. Вот как это сделать онлайн.' },
          { h2: 'Изменение цен и товаров', p: 'В админ-панели откройте товар, измените цену или описание и сохраните — изменение сразу видно всем гостям.' },
          { h2: 'Управление наличием', p: 'Проданное блюдо отметьте как «нет в наличии» в один клик, и гости не будут его заказывать.' },
        ],
      },
      en: {
        title: 'How to update your restaurant menu online',
        description: 'How to instantly update your restaurant menu online: prices, items, availability.',
        excerpt: 'An online menu updates in seconds. Here’s how.',
        body: [
          { p: 'One of the biggest advantages of a digital menu is instant updating. Here’s how to do it online.' },
          { h2: 'Changing prices and items', p: 'In the admin panel, open the item, change the price or description and save — the change is instantly visible to all guests.' },
          { h2: 'Managing availability', p: 'Mark a sold-out dish as “unavailable” in one click, and guests won’t order it.' },
        ],
      },
    },
  },
  {
    slug: 'digital-menu',
    title: 'Ինչու ընտրել թվային մենյու',
    description: 'Թվային մենյուի առավելությունները ռեստորանների և սրճարանների համար՝ ծախս, փորձառություն, ճկունություն։',
    date: '2026-07-06',
    keyword: 'Digital Menu',
    excerpt: 'Թվային մենյուն ոչ միայն ժամանակակից է, այլև խնայող ու ճկուն։ Ահա ինչու։',
    body: [
      { p: 'Թվային մենյուն արագ դառնում է ստանդարտ սննդի ոլորտում։ Ահա հիմնական պատճառները, թե ինչու են բիզնեսներն ընտրում այն։' },
      { h2: 'Ծախսերի խնայողություն', p: 'Ոչ մի վերատպություն — մենյուն թարմացվում է թվային եղանակով, անվճար։' },
      { h2: 'Ավելի լավ փորձառություն', p: 'Լուսանկարներ, բազմալեզու ներկայացում և հարմար նավիգացիա՝ ավելի բավարարված հաճախորդներ։' },
    ],
    published: true,
    i18n: {
      ru: {
        title: 'Почему стоит выбрать цифровое меню',
        description: 'Преимущества цифрового меню для ресторанов и кафе: стоимость, впечатление, гибкость.',
        excerpt: 'Цифровое меню не только современно, но и экономно и гибко. Вот почему.',
        body: [
          { p: 'Цифровое меню быстро становится стандартом в сфере питания. Вот основные причины, почему бизнесы его выбирают.' },
          { h2: 'Экономия расходов', p: 'Никаких перепечаток — меню обновляется в цифровом виде, бесплатно.' },
          { h2: 'Лучшее впечатление', p: 'Фото, многоязычная подача и удобная навигация — более довольные гости.' },
        ],
      },
      en: {
        title: 'Why choose a digital menu',
        description: 'The advantages of a digital menu for restaurants and cafés: cost, experience, flexibility.',
        excerpt: 'A digital menu is not only modern but also economical and flexible. Here’s why.',
        body: [
          { p: 'A digital menu is quickly becoming the standard in the food industry. Here are the main reasons businesses choose it.' },
          { h2: 'Cost savings', p: 'No reprinting — the menu updates digitally, for free.' },
          { h2: 'A better experience', p: 'Photos, multilingual presentation and convenient navigation — more satisfied guests.' },
        ],
      },
    },
  },
  {
    slug: 'qr-menu-benefits',
    title: 'QR Menu-ի առավելությունները',
    description: 'QR Menu-ի հիմնական առավելությունները ռեստորանների համար՝ արագություն, ճկունություն, խնայողություն, հիգիենա։',
    date: '2026-07-07',
    keyword: 'QR Menu',
    excerpt: 'QR Menu-ի 6 հիմնական առավելությունը, որ կփոխեն ձեր ռեստորանի աշխատանքը։',
    body: [
      { p: 'QR Menu-ն առաջարկում է մի շարք առավելություններ ինչպես բիզնեսի, այնպես էլ հաճախորդի համար։' },
      { h2: 'Բիզնեսի համար', p: 'Ծախսերի խնայողություն, ակնթարթային թարմացումներ, վիճակագրություն և ավելի բարձր միջին չեկ։' },
      { h2: 'Հաճախորդի համար', p: 'Արագ հասանելիություն, գեղեցիկ լուսանկարներ, բազմալեզու մենյու և հիգիենիկ փորձառություն։' },
    ],
    published: true,
    i18n: {
      ru: {
        title: 'Преимущества QR Menu',
        description: 'Основные преимущества QR Menu для ресторанов: скорость, гибкость, экономия, гигиена.',
        excerpt: '6 ключевых преимуществ QR Menu, которые изменят работу вашего ресторана.',
        body: [
          { p: 'QR Menu предлагает ряд преимуществ как для бизнеса, так и для гостя.' },
          { h2: 'Для бизнеса', p: 'Экономия расходов, мгновенные обновления, статистика и более высокий средний чек.' },
          { h2: 'Для гостя', p: 'Быстрый доступ, красивые фото, многоязычное меню и гигиеничный опыт.' },
        ],
      },
      en: {
        title: 'The advantages of a QR Menu',
        description: 'The main advantages of a QR Menu for restaurants: speed, flexibility, savings, hygiene.',
        excerpt: '6 key advantages of a QR Menu that will change how your restaurant works.',
        body: [
          { p: 'A QR Menu offers a range of advantages for both the business and the guest.' },
          { h2: 'For the business', p: 'Cost savings, instant updates, analytics and a higher average check.' },
          { h2: 'For the guest', p: 'Fast access, beautiful photos, a multilingual menu and a hygienic experience.' },
        ],
      },
    },
  },
  {
    slug: 'restaurant-digital-menu-guide',
    title: 'Restaurant Digital Menu Guide',
    description: 'Ամբողջական ուղեցույց ռեստորանի թվային մենյուի մասին՝ ինչպես ստեղծել, կառավարել և օպտիմիզացնել այն։',
    date: '2026-07-08',
    keyword: 'Restaurant Menu',
    excerpt: 'Ամեն ինչ, ինչ պետք է իմանաք ռեստորանի թվային մենյուի մասին՝ մեկ ուղեցույցում։',
    body: [
      { p: 'Ռեստորանի թվային մենյուն (Restaurant Digital Menu) ձեր ապրանքների ամբողջական թվային ներկայացումն է։ Այս ուղեցույցը ընդգրկում է հիմունքները։' },
      { h2: 'Կառուցվածք', p: 'Կազմակերպեք մենյուն բաժիններով և կատեգորիաներով՝ ուտեստներ, ըմպելիքներ, աղանդեր, որպեսզի հաճախորդը հեշտ գտնի ուզածը։' },
      { h2: 'Օպտիմիզացիա', p: 'Ավելացրեք լուսանկարներ, հստակ նկարագրություններ և առանձնացրեք հիթ ապրանքները վաճառքը մեծացնելու համար։' },
    ],
    published: true,
    i18n: {
      ru: {
        title: 'Руководство по цифровому меню ресторана',
        description: 'Полное руководство по цифровому меню ресторана: как создать, управлять и оптимизировать его.',
        excerpt: 'Всё, что нужно знать о цифровом меню ресторана, — в одном руководстве.',
        body: [
          { p: 'Цифровое меню ресторана (Restaurant Digital Menu) — это полное цифровое представление ваших товаров. Это руководство охватывает основы.' },
          { h2: 'Структура', p: 'Организуйте меню разделами и категориями — блюда, напитки, десерты, чтобы гость легко нашёл нужное.' },
          { h2: 'Оптимизация', p: 'Добавьте фото, чёткие описания и выделите хиты продаж, чтобы увеличить продажи.' },
        ],
      },
      en: {
        title: 'Restaurant Digital Menu Guide',
        description: 'A complete guide to a restaurant’s digital menu: how to create, manage and optimize it.',
        excerpt: 'Everything you need to know about a restaurant’s digital menu — in one guide.',
        body: [
          { p: 'A Restaurant Digital Menu is the full digital presentation of your products. This guide covers the basics.' },
          { h2: 'Structure', p: 'Organize the menu into sections and categories — dishes, drinks, desserts — so guests easily find what they want.' },
          { h2: 'Optimization', p: 'Add photos, clear descriptions and highlight best-sellers to increase sales.' },
        ],
      },
    },
  },
  {
    slug: 'online-menu-vs-paper-menu',
    title: 'Online Menu vs Paper Menu',
    description: 'Online Menu-ի և թղթային մենյուի համեմատություն․ ո՞րն է ավելի լավը ձեր ռեստորանի համար։',
    date: '2026-07-09',
    keyword: 'Online Menu',
    excerpt: 'Online Menu թե՞ թղթ․ ուղիղ համեմատություն՝ գնի, արագության և փորձառության վրա։',
    body: [
      { p: 'Online Menu-ն և թղթային մենյուն սպասարկում են նույն նպատակին, բայց շատ տարբեր են արդյունավետությամբ։' },
      { h2: 'Երբ թղթ, երբ առցանց', p: 'Թղթը ծանոթ է, բայց ստատիկ և ծախսատար։ Online Menu-ն դինամիկ է, թարմացվող և բազմալեզու։' },
      { h2: 'Եզրակացություն', p: 'Աճող թվով ռեստորաններ անցնում են Online Menu-ի ճկունության և խնայողության համար, հաճախ երկուսը զուգակցելով անցումային շրջանում։' },
    ],
    published: true,
    i18n: {
      ru: {
        title: 'Онлайн-меню против бумажного меню',
        description: 'Сравнение онлайн-меню и бумажного меню: что лучше для вашего ресторана.',
        excerpt: 'Онлайн-меню или бумага? Прямое сравнение по цене, скорости и впечатлению.',
        body: [
          { p: 'Онлайн-меню и бумажное меню служат одной цели, но сильно различаются по эффективности.' },
          { h2: 'Когда бумага, когда онлайн', p: 'Бумага привычна, но статична и затратна. Онлайн-меню динамично, обновляемо и многоязычно.' },
          { h2: 'Вывод', p: 'Всё больше ресторанов переходят на онлайн-меню ради гибкости и экономии, часто совмещая оба на переходном этапе.' },
        ],
      },
      en: {
        title: 'Online Menu vs Paper Menu',
        description: 'A comparison of an online menu and a paper menu: which is better for your restaurant.',
        excerpt: 'Online menu or paper? A direct comparison on cost, speed and experience.',
        body: [
          { p: 'An online menu and a paper menu serve the same purpose but differ greatly in efficiency.' },
          { h2: 'When paper, when online', p: 'Paper is familiar but static and costly. An online menu is dynamic, updatable and multilingual.' },
          { h2: 'Conclusion', p: 'A growing number of restaurants switch to an online menu for flexibility and savings, often combining both during the transition.' },
        ],
      },
    },
  },
  {
    slug: 'qr-menu-armenia',
    title: 'QR Menu Armenia — QR մենյու Հայաստանում',
    description: 'QR Menu-ն Հայաստանում․ ինչպես հայկական ռեստորաններն ու սրճարանները անցնում են թվային մենյուի։',
    date: '2026-07-10',
    keyword: 'QR Menu Armenia',
    excerpt: 'Ինչպես է QR Menu-ն տարածվում Հայաստանում և ինչու է դա կարևոր տեղական բիզնեսների համար։',
    body: [
      { p: 'Հայաստանում QR Menu-ն արագ դառնում է ստանդարտ ռեստորանների, սրճարանների և բարերի համար՝ հատկապես զբոսաշրջության աճի ֆոնին։' },
      { h2: 'Տեղական կարիքներ', p: 'Հայկական բիզնեսներին պետք է հայերեն ինտերֆեյս, դրամով գնագոյացում և բազմալեզու մենյու տեղացիների ու զբոսաշրջիկների համար։' },
      { h2: 'menus.am-ը', p: 'menus.am-ը հայկական հարթակ է, ստեղծված հենց այս կարիքների համար՝ տեղական աջակցությամբ և հայկական խոհանոցին հարմար թեմաներով։' },
    ],
    published: true,
    i18n: {
      ru: {
        title: 'QR Menu Armenia — QR-меню в Армении',
        description: 'QR Menu в Армении: как армянские рестораны и кафе переходят на цифровое меню.',
        excerpt: 'Как QR Menu распространяется в Армении и почему это важно для местного бизнеса.',
        body: [
          { p: 'В Армении QR Menu быстро становится стандартом для ресторанов, кафе и баров — особенно на фоне роста туризма.' },
          { h2: 'Локальные потребности', p: 'Армянскому бизнесу нужен интерфейс на армянском, ценообразование в драмах и многоязычное меню — для местных и туристов.' },
          { h2: 'menus.am', p: 'menus.am — армянская платформа, созданная именно под эти потребности: с локальной поддержкой и темами под армянскую кухню.' },
        ],
      },
      en: {
        title: 'QR Menu Armenia — QR menu in Armenia',
        description: 'QR Menu in Armenia: how Armenian restaurants and cafés are moving to a digital menu.',
        excerpt: 'How QR Menu is spreading in Armenia and why it matters for local businesses.',
        body: [
          { p: 'In Armenia, QR Menu is quickly becoming the standard for restaurants, cafés and bars — especially amid growing tourism.' },
          { h2: 'Local needs', p: 'Armenian businesses need an Armenian interface, pricing in drams and a multilingual menu — for locals and tourists.' },
          { h2: 'menus.am', p: 'menus.am is an Armenian platform built for exactly these needs — with local support and themes suited to Armenian cuisine.' },
        ],
      },
    },
  },
  {
    slug: 'best-qr-menu-armenia',
    title: 'Լավագույն QR Menu հարթակները Հայաստանում (2026)',
    description: 'Ինչպես ընտրել լավագույն QR Menu հարթակը Հայաստանում․ չափանիշներ, համեմատություն և ինչու menus.am-ը տեղական լավագույն ընտրությունն է։',
    date: '2026-07-12',
    keyword: 'QR Menu Armenia',
    excerpt: 'Ինչ չափանիշներով ընտրել QR Menu հարթակ Հայաստանում, և ինչու menus.am-ը տեղական բիզնեսների համար լավագույն տարբերակն է։',
    body: [
      { p: 'QR Menu-ն Հայաստանում արագ դառնում է ստանդարտ ռեստորանների, սրճարանների և բարերի համար։ Բայց հարթակ ընտրելիս կարևոր է նայել ոչ միայն գնին, այլև տեղական կարիքներին՝ հայերեն ինտերֆեյս, դրամով գնագոյացում և բազմալեզու մենյու։ Ահա հիմնական չափանիշները և ինչու menus.am-ը առաջատարն է տեղական շուկայում։' },
      { h2: 'Ընտրության չափանիշները', p: 'Լավ QR Menu հարթակը պետք է ունենա՝ բազմալեզու աջակցություն (հայերեն, ռուսերեն, անգլերեն), հեշտ ինքնուրույն կառավարում, ակնթարթային թարմացումներ, պրեմիում դիզայն-թեմաներ, թափանցիկ գնացուցակ դրամով և տեղական աջակցություն։ Միջազգային հարթակները հաճախ չունեն հայերեն ինտերֆեյս կամ դրամով վճարում։' },
      { h2: 'Ինչու menus.am', p: 'menus.am-ը հայկական հարթակ է, ստեղծված հենց Հայաստանի սննդի բիզնեսների համար՝ հայերեն ինտերֆեյս, դրամով գնագոյացում (սկսվում է ամսական 4 900 ֏-ից), 3 լեզու, AI թարգմանություն և AI նկարագրություններ, պրեմիում թեմաներ և տեղական աջակցություն։ Մենյուն թարմացվում է ակնթարթորեն, իսկ QR կոդը տպվում ու դրվում է սեղանների վրա։' },
      { h2: 'Փաթեթներ և գին', p: 'menus.am-ը առաջարկում է 3 փաթեթ․ Starter (սկսնակների համար, ամսական 4 900 ֏-ից), Professional (անսահմանափակ ապրանք, 3 լեզու, AI, ամսական 9 900 ֏) և Business (սեփական դոմեն, բազմաթիվ օգտատերեր, վիճակագրություն, ամսական 29 900 ֏)։ Բոլոր փաթեթները կարող ես բարձրացնել ցանկացած պահի։' },
      { h2: 'Եզրակացություն', p: 'Եթե Հայաստանում ես ու ուզում ես QR Menu, որ իսկապես համապատասխանի տեղական կարիքներին՝ հայերեն, դրամով, բազմալեզու և տեղական աջակցությամբ, menus.am-ը ամենախորհրդատվական ընտրությունն է։' },
    ],
    published: true,
    i18n: {
      ru: {
        title: 'Лучшие платформы QR Menu в Армении (2026)',
        description: 'Как выбрать лучшую платформу QR Menu в Армении: критерии, сравнение и почему menus.am — лучший локальный выбор.',
        excerpt: 'По каким критериям выбирать платформу QR Menu в Армении и почему menus.am — лучший вариант для местного бизнеса.',
        body: [
          { p: 'QR Menu в Армении быстро становится стандартом для ресторанов, кафе и баров. Но при выборе платформы важно смотреть не только на цену, но и на локальные потребности — армянский интерфейс, ценообразование в драмах и многоязычное меню. Вот основные критерии и почему menus.am — лидер на местном рынке.' },
          { h2: 'Критерии выбора', p: 'Хорошая платформа QR Menu должна иметь: многоязычную поддержку (армянский, русский, английский), простое самостоятельное управление, мгновенные обновления, премиум-темы, прозрачные тарифы в драмах и локальную поддержку. У международных платформ часто нет армянского интерфейса или оплаты в драмах.' },
          { h2: 'Почему menus.am', p: 'menus.am — армянская платформа, созданная именно для заведений питания Армении: армянский интерфейс, ценообразование в драмах (от 4 900 ֏ в месяц), 3 языка, AI-перевод и AI-описания, премиум-темы и локальная поддержка. Меню обновляется мгновенно, а QR-код печатается и размещается на столах.' },
          { h2: 'Тарифы и цена', p: 'menus.am предлагает 3 тарифа: Starter (для начинающих, от 4 900 ֏/мес), Professional (неограниченно товаров, 3 языка, AI, 9 900 ֏/мес) и Business (свой домен, несколько пользователей, статистика, 29 900 ֏/мес). Любой тариф можно повысить в любой момент.' },
          { h2: 'Вывод', p: 'Если вы в Армении и хотите QR Menu, которое действительно отвечает местным потребностям — армянский, драмы, многоязычность и локальная поддержка, — menus.am самый рекомендуемый выбор.' },
        ],
      },
      en: {
        title: 'Best QR Menu Platforms in Armenia (2026)',
        description: 'How to choose the best QR Menu platform in Armenia: criteria, comparison and why menus.am is the best local choice.',
        excerpt: 'What criteria to choose a QR Menu platform by in Armenia, and why menus.am is the best option for local businesses.',
        body: [
          { p: 'In Armenia, QR Menu is quickly becoming the standard for restaurants, cafés and bars. But when choosing a platform, it is important to look beyond price at local needs — an Armenian interface, pricing in drams and a multilingual menu. Here are the key criteria and why menus.am leads the local market.' },
          { h2: 'Selection criteria', p: 'A good QR Menu platform should have: multilingual support (Armenian, Russian, English), easy self-service management, instant updates, premium themes, transparent pricing in drams and local support. International platforms often lack an Armenian interface or dram billing.' },
          { h2: 'Why menus.am', p: 'menus.am is an Armenian platform built specifically for Armenia food businesses: an Armenian interface, pricing in drams (from 4,900 dram/month), 3 languages, AI translation and AI descriptions, premium themes and local support. The menu updates instantly, and the QR code is printed and placed on the tables.' },
          { h2: 'Plans and pricing', p: 'menus.am offers 3 plans: Starter (for beginners, from 4,900 dram/mo), Professional (unlimited products, 3 languages, AI, 9,900 dram/mo) and Business (custom domain, multiple users, analytics, 29,900 dram/mo). Any plan can be upgraded at any time.' },
          { h2: 'Conclusion', p: 'If you are in Armenia and want a QR Menu that truly fits local needs — Armenian, drams, multilingual and local support — menus.am is the most recommended choice.' },
        ],
      },
    },
  },
  {
    slug: 'qr-menu-restaurant',
    title: 'QR Menu Restaurant',
    description: 'QR Menu ռեստորանի համար՝ ինչ է դա, ինչ առավելություններ ունի և ինչպես ստեղծել ձեր ռեստորանի QR մենյուն րոպեների ընթացքում menus.am-ում։',
    date: '2026-07-13',
    keyword: 'QR Menu',
    excerpt: 'QR Menu-ն ռեստորանի համար դառնում է ստանդարտ․ ահա ինչ է դա, ինչ է տալիս և ինչպես ստեղծել ձերը։',
    body: [
      { p: 'Ռեստորանների համար QR Menu-ն այլևս նորություն չէ, այլ ստանդարտ։ Հաճախորդը սկանավորում է սեղանի QR կոդը հեռախոսով և ակնթարթորեն տեսնում ամբողջ մենյուն՝ լուսանկարներով, գներով և նկարագրություններով։ Այս ուղեցույցում կպատմենք, թե ինչ է QR Menu-ն ռեստորանի համար, ինչ առավելություններ ունի և ինչպես ստեղծել ձերը րոպեների ընթացքում։' },
      { h2: 'Ինչ է QR Menu-ն ռեստորանի համար', p: 'QR Menu-ն ձեր ռեստորանի մենյուն է թվային տեսքով՝ հասանելի QR կոդի միջոցով։ Հաճախորդը սկանավորում է կոդը հեռախոսի տեսախցիկով, առանց հավելված ներբեռնելու, և բացում ձեր մենյուն ցանկացած սարքից։ Մենյուն միշտ արդիական է. գնի կամ ապրանքի ցանկացած փոփոխություն երևում է անմիջապես։' },
      { h2: 'Ինչու է QR Menu-ն կարևոր ռեստորանների համար', p: 'QR Menu-ն խնայում է տպագրության ծախսերը, թույլ է տալիս ակնթարթորեն թարմացնել գներն ու ապրանքները, նշել վաճառված ուտեստները «սպառված» և ցուցադրել ախորժալի լուսանկարներ, որոնք բարձրացնում են միջին չեկը։ Այն նաև հիգիենիկ է՝ մենյուն ձեռքից ձեռք չի անցնում։' },
      { h2: 'Ինչպես ստեղծել ռեստորանի QR Menu', p: '1) Գրանցվեք menus.am-ում։ 2) Ընտրեք ձեր բրենդին համապատասխան պրեմիում թեմա։ 3) Ավելացրեք բաժիններ, կատեգորիաներ և ապրանքներ՝ գներով, նկարագրություններով և լուսանկարներով, մինչև 3 լեզվով։ 4) Ստացեք ձեր QR կոդը, տպեք և տեղադրեք սեղանների վրա։ Ամբողջ գործընթացը տևում է րոպեներ և չի պահանջում տեխնիկական գիտելիք։' },
      { h2: 'Բազմալեզու QR մենյու ռեստորանի համար', p: 'Ներկայացրեք ձեր ռեստորանի մենյուն հայերեն, ռուսերեն և անգլերեն՝ ավտոմատ լեզվի փոխարկումով։ Զբոսաշրջիկների և բազմազգ հաճախորդների համար բազմալեզու մենյուն մեծացնում է պատվերները և բարելավում փորձառությունը։' },
      { h2: 'menus.am-ը ռեստորանների համար', p: 'menus.am-ը հայկական հարթակ է, ստեղծված ռեստորանների, սրճարանների և բարերի համար՝ դրամով գնագոյացում, տեղական աջակցություն, պրեմիում թեմաներ և AI թարգմանություն։ QR Menu-ն սկսվում է ամսական 4 900 ֏-ից, և կարող եք ստեղծել ձերը հենց այսօր։' },
    ],
    published: true,
    i18n: {
      ru: {
        title: 'QR Menu ресторан',
        description: 'QR Menu для ресторана: что это, какие преимущества и как создать QR-меню вашего ресторана за минуты на menus.am.',
        excerpt: 'QR Menu становится стандартом для ресторанов: вот что это, что оно даёт и как создать своё.',
        body: [
          { p: 'Для ресторанов QR Menu — уже не новинка, а стандарт. Гость сканирует QR-код на столе телефоном и мгновенно видит всё меню — с фото, ценами и описаниями. В этом руководстве расскажем, что такое QR Menu для ресторана, какие у него преимущества и как создать своё за минуты.' },
          { h2: 'Что такое QR Menu для ресторана', p: 'QR Menu — это меню вашего ресторана в цифровом виде, доступное через QR-код. Гость сканирует код камерой телефона, без скачивания приложения, и открывает меню с любого устройства. Меню всегда актуально: любое изменение цены или товара отображается сразу.' },
          { h2: 'Почему QR Menu важно для ресторанов', p: 'QR Menu экономит на печати, позволяет мгновенно обновлять цены и товары, отмечать проданные блюда как «нет в наличии» и показывать аппетитные фото, повышающие средний чек. Оно также гигиенично — меню не передаётся из рук в руки.' },
          { h2: 'Как создать QR Menu ресторана', p: '1) Зарегистрируйтесь на menus.am. 2) Выберите премиум-тему под ваш бренд. 3) Добавьте разделы, категории и товары — с ценами, описаниями и фото, до 3 языков. 4) Получите QR-код, распечатайте и разместите на столах. Весь процесс занимает минуты и не требует технических знаний.' },
          { h2: 'Многоязычное QR-меню ресторана', p: 'Показывайте меню ресторана на армянском, русском и английском с автоматическим переключением языка. Для туристов и многонациональных гостей многоязычное меню увеличивает заказы и улучшает впечатление.' },
          { h2: 'menus.am для ресторанов', p: 'menus.am — армянская платформа, созданная для ресторанов, кафе и баров: ценообразование в драмах, локальная поддержка, премиум-темы и AI-перевод. QR Menu начинается от 4 900 ֏ в месяц, и вы можете создать своё уже сегодня.' },
        ],
      },
      en: {
        title: 'QR Menu Restaurant',
        description: 'QR Menu for restaurants: what it is, its advantages and how to create your restaurant QR menu in minutes on menus.am.',
        excerpt: 'A QR Menu is becoming the standard for restaurants — here is what it is, what it offers and how to create yours.',
        body: [
          { p: 'For restaurants, a QR Menu is no longer a novelty but a standard. The guest scans the QR code on the table with their phone and instantly sees the full menu — with photos, prices and descriptions. This guide explains what a QR Menu for a restaurant is, its advantages and how to create yours in minutes.' },
          { h2: 'What is a QR Menu for a restaurant', p: 'A QR Menu is your restaurant menu in digital form, accessible via a QR code. The guest scans the code with their phone camera, without downloading an app, and opens the menu on any device. The menu is always up to date: any price or item change appears immediately.' },
          { h2: 'Why a QR Menu matters for restaurants', p: 'A QR Menu saves on printing, lets you instantly update prices and items, mark sold-out dishes as "unavailable" and show appetizing photos that raise the average check. It is also hygienic — the menu is not passed hand to hand.' },
          { h2: 'How to create a restaurant QR Menu', p: '1) Sign up on menus.am. 2) Choose a premium theme for your brand. 3) Add sections, categories and products — with prices, descriptions and photos, in up to 3 languages. 4) Get your QR code, print it and place it on the tables. The whole process takes minutes and requires no technical knowledge.' },
          { h2: 'Multilingual restaurant QR menu', p: 'Show your restaurant menu in Armenian, Russian and English with automatic language switching. For tourists and multinational guests, a multilingual menu increases orders and improves the experience.' },
          { h2: 'menus.am for restaurants', p: 'menus.am is an Armenian platform built for restaurants, cafés and bars: pricing in drams, local support, premium themes and AI translation. A QR Menu starts at 4,900 dram/month, and you can create yours today.' },
        ],
      },
    },
  },
  {
    slug: 'qr-menu',
    title: 'QR Menu',
    description: 'QR Menu՝ ի՞նչ է, ինչպես է աշխատում, ինչ առավելություններ ունի և ինչպես ստեղծել ձեր թվային QR մենյուն րոպեների ընթացքում menus.am-ում։',
    date: '2026-07-14',
    keyword: 'QR Menu',
    excerpt: 'Ամեն ինչ QR Menu-ի մասին՝ ի՞նչ է դա, ինչպես է աշխատում, ինչու է պետք և ինչպես ստեղծել ձերը։',
    body: [
      { p: 'QR Menu-ն սննդի ոլորտի ամենաարագ տարածվող գործիքներից մեկն է․ թվային մենյու, որը հաճախորդը բացում է հեռախոսով՝ սեղանի QR կոդը սկանավորելով։ Այս ուղեցույցում կանդրադառնանք ամեն ինչի՝ ի՞նչ է QR Menu-ն, ինչպես է աշխատում, ինչ առավելություններ ունի և ինչպես ստեղծել ձերը րոպեների ընթացքում։' },
      { h2: 'Ի՞նչ է QR Menu-ն', p: 'QR Menu-ն ռեստորանի, սրճարանի կամ բարի մենյուն է թվային տեսքով՝ հասանելի QR կոդի միջոցով։ Հաճախորդը սկանավորում է կոդը հեռախոսի տեսախցիկով, առանց հավելված ներբեռնելու, և ակնթարթորեն տեսնում ամբողջ մենյուն՝ լուսանկարներով, գներով և նկարագրություններով։' },
      { h2: 'Ինչպես է աշխատում QR Menu-ն', p: 'Հաստատությունը ստեղծում է իր թվային մենյուն կառավարման վահանակից, համակարգն ավտոմատ գեներացնում է եզակի QR կոդ, իսկ դուք տպում և տեղադրում եք այն սեղանների վրա։ Հաճախորդը սկանավորում է կոդը և բացում ձեր բրենդին համապատասխան մենյուն ցանկացած սարքից։' },
      { h2: 'QR Menu-ի առավելությունները', p: 'QR Menu-ն միշտ արդիական է. գնի կամ ապրանքի ցանկացած փոփոխություն երևում է անմիջապես՝ առանց վերատպելու։ Այն խնայում է տպագրության ծախսերը, ցուցադրում է ախորժալի լուսանկարներ, աշխատում է բազմալեզու, թույլ է տալիս նշել վաճառված ուտեստները և հիգիենիկ է՝ չի անցնում ձեռքից ձեռք։' },
      { h2: 'Ինչպես ստեղծել QR Menu', p: '1) Գրանցվեք menus.am-ում։ 2) Ընտրեք ձեր բրենդին համապատասխան պրեմիում թեմա։ 3) Ավելացրեք բաժիններ, կատեգորիաներ և ապրանքներ՝ գներով, նկարագրություններով և լուսանկարներով, մինչև 3 լեզվով։ 4) Ստացեք ձեր QR կոդը, տպեք և տեղադրեք սեղանների վրա։ Ամբողջ գործընթացը տևում է րոպեներ և չի պահանջում տեխնիկական գիտելիք։' },
      { h2: 'Բազմալեզու QR Menu', p: 'Ներկայացրեք ձեր մենյուն հայերեն, ռուսերեն և անգլերեն՝ ավտոմատ լեզվի փոխարկումով։ Զբոսաշրջիկների և բազմազգ հաճախորդների համար բազմալեզու մենյուն մեծացնում է պատվերները և բարելավում փորձառությունը։' },
      { h2: 'QR Menu-ի գինը menus.am-ում', p: 'menus.am-ում QR Menu-ն սկսվում է ամսական 4 900 ֏-ից՝ Starter փաթեթով, որը ներառում է կառավարման վահանակ, 2 լեզու և պրեմիում մենյու։ Professional և Business փաթեթներն ավելացնում են անսահմանափակ ապրանքներ, 3 լեզու, բոլոր թեմաներն ու AI հնարավորությունները՝ տեղական աջակցությամբ և դրամով գնագոյացմամբ։' },
    ],
    published: true,
    i18n: {
      ru: {
        title: 'QR Menu',
        description: 'QR Menu: что это, как работает, какие преимущества и как создать ваше цифровое QR-меню за минуты на menus.am.',
        excerpt: 'Всё о QR Menu: что это, как работает, зачем нужно и как создать своё.',
        body: [
          { p: 'QR Menu — один из самых быстро распространяющихся инструментов в сфере питания: цифровое меню, которое гость открывает на телефоне, сканируя QR-код на столе. В этом руководстве разберём всё: что такое QR Menu, как оно работает, какие преимущества и как создать своё за минуты.' },
          { h2: 'Что такое QR Menu', p: 'QR Menu — это меню ресторана, кафе или бара в цифровом виде, доступное через QR-код. Гость сканирует код камерой телефона, без скачивания приложения, и мгновенно видит всё меню — с фото, ценами и описаниями.' },
          { h2: 'Как работает QR Menu', p: 'Заведение создаёт цифровое меню в панели управления, система автоматически генерирует уникальный QR-код, а вы печатаете его и размещаете на столах. Гость сканирует код и открывает меню под ваш бренд с любого устройства.' },
          { h2: 'Преимущества QR Menu', p: 'QR Menu всегда актуально: любое изменение цены или товара отображается сразу, без перепечатки. Оно экономит на печати, показывает аппетитные фото, работает многоязычно, позволяет отмечать проданные блюда и гигиенично — не передаётся из рук в руки.' },
          { h2: 'Как создать QR Menu', p: '1) Зарегистрируйтесь на menus.am. 2) Выберите премиум-тему под ваш бренд. 3) Добавьте разделы, категории и товары — с ценами, описаниями и фото, до 3 языков. 4) Получите QR-код, распечатайте и разместите на столах. Весь процесс занимает минуты и не требует технических знаний.' },
          { h2: 'Многоязычное QR Menu', p: 'Показывайте меню на армянском, русском и английском с автоматическим переключением языка. Для туристов и многонациональных гостей многоязычное меню увеличивает заказы и улучшает впечатление.' },
          { h2: 'Цена QR Menu на menus.am', p: 'На menus.am QR Menu начинается от 4 900 ֏ в месяц с тарифом Starter, включающим панель управления, 2 языка и премиум-меню. Тарифы Professional и Business добавляют неограниченно товаров, 3 языка, все темы и AI-возможности — с локальной поддержкой и ценообразованием в драмах.' },
        ],
      },
      en: {
        title: 'QR Menu',
        description: 'QR Menu: what it is, how it works, its advantages and how to create your digital QR menu in minutes on menus.am.',
        excerpt: 'Everything about a QR Menu: what it is, how it works, why you need it and how to create yours.',
        body: [
          { p: 'A QR Menu is one of the fastest-spreading tools in the food industry: a digital menu the guest opens on their phone by scanning the QR code on the table. This guide covers it all — what a QR Menu is, how it works, its advantages and how to create yours in minutes.' },
          { h2: 'What is a QR Menu', p: 'A QR Menu is a restaurant, café or bar menu in digital form, accessible via a QR code. The guest scans the code with their phone camera, without downloading an app, and instantly sees the full menu — with photos, prices and descriptions.' },
          { h2: 'How a QR Menu works', p: 'The venue creates its digital menu in the admin panel, the system automatically generates a unique QR code, and you print and place it on the tables. The guest scans the code and opens a menu that matches your brand, from any device.' },
          { h2: 'Advantages of a QR Menu', p: 'A QR Menu is always up to date: any price or item change appears immediately, with no reprinting. It saves on printing, shows appetizing photos, works multilingually, lets you mark sold-out dishes and is hygienic — not passed hand to hand.' },
          { h2: 'How to create a QR Menu', p: '1) Sign up on menus.am. 2) Choose a premium theme for your brand. 3) Add sections, categories and products — with prices, descriptions and photos, in up to 3 languages. 4) Get your QR code, print it and place it on the tables. The whole process takes minutes and requires no technical knowledge.' },
          { h2: 'Multilingual QR Menu', p: 'Show your menu in Armenian, Russian and English with automatic language switching. For tourists and multinational guests, a multilingual menu increases orders and improves the experience.' },
          { h2: 'QR Menu price on menus.am', p: 'On menus.am a QR Menu starts at 4,900 dram/month with the Starter plan, which includes the admin panel, 2 languages and a premium menu. The Professional and Business plans add unlimited products, 3 languages, all themes and AI features — with local support and pricing in drams.' },
        ],
      },
    },
  },
]

/** Return the article with its visible fields swapped to the chosen language.
 *  `hy` (or a missing translation) returns the base article unchanged, so SSR
 *  and <head>/JSON-LD keep the Armenian content for SEO. */
export const localizeArticle = (a: BlogArticle, lang: BlogLang): BlogArticle => {
  if (lang === 'hy' || !a.i18n?.[lang]) return a
  const t = a.i18n[lang]
  return { ...a, title: t.title, description: t.description, excerpt: t.excerpt, body: t.body }
}

export const publishedArticles = () =>
  [...blogArticles].filter((a) => a.published).sort((a, b) => b.date.localeCompare(a.date))

export const getArticle = (slug: string) => blogArticles.find((a) => a.slug === slug && a.published)
