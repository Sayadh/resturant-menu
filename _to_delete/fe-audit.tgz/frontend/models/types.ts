// ─────────────────────────────────────────────────────────────────────────
// Universal QR-Menu platform — backend-ready domain model.
//
// These interfaces describe the data exactly as a real API would return it.
// Today they are served by the mock service layer (services/*), tomorrow by a
// REST/GraphQL backend — the shape stays identical so nothing downstream needs
// to change. The admin panel and every public theme consume THIS model.
// ─────────────────────────────────────────────────────────────────────────

/** Supported interface / content languages. */
export type LangCode = 'hy' | 'en' | 'ru'

/** A translatable string. Always carries all supported languages. */
export interface Translation {
  hy: string
  en: string
  ru: string
}

/** Product highlight badges. */
export type Badge = 'hit' | 'new' | 'recommended' | 'spicy' | 'vegan' | 'affordable'

/** Available public theme identifiers. */
export type ThemeId = 'aria' | 'atelier' | 'maison' | 'heritage' | 'noir' | 'opaline'

// ── Menu ────────────────────────────────────────────────────────────────
/** A dynamic, per-restaurant top-level section (Food, Drinks, …). */
export interface Section {
  id: string
  restaurantId: string
  name: Translation
  icon: string
  /** Uploaded section image (optional). */
  image: string
  sortOrder: number
  active: boolean
}

export interface Category {
  id: string
  restaurantId: string
  sectionId: string
  name: Translation
  description: Translation
  icon: string
  /** Small category icon image (uploaded). */
  iconImage: string
  /** Desktop banner image. */
  image: string
  /** Mobile banner image (falls back to `image`). */
  mobileImage: string
  /** Banner title colour over the image: 'light' (white) or 'dark'. */
  bannerTextColor: 'light' | 'dark'
  sortOrder: number
  active: boolean
}

export interface Product {
  id: string
  restaurantId: string
  categoryId: string
  /** Resolved from the product's category (read-only convenience). */
  sectionId: string
  name: Translation
  description: Translation
  /** Price in minor-less AMD (whole drams). */
  price: number
  image: string
  badges: Badge[]
  active: boolean
  available: boolean
  sortOrder: number
}

// ── Order (client-side, no payment) ───────────────────────────────────────
export interface OrderItem {
  productId: string
  qty: number
}

// ── Theme ──────────────────────────────────────────────────────────────
export interface Theme {
  id: ThemeId
  name: string
  description: string
  bestFor: string
  /** Screenshot/preview asset (placeholder until real screenshots exist). */
  screenshot: string
  accent: string
  /** Whether the theme is implemented and selectable. */
  available: boolean
}

/** Controlled, theme-safe customization applied on top of any theme. */
export interface ThemeSettings {
  themeId: ThemeId
  primaryColor: string
  secondaryColor: string
  backgroundColor: string
  accentColor: string
  fontStyle: 'classic' | 'modern' | 'editorial'
  logo: string
  coverImage: string
  cardRadius: number
  showRating: boolean
  showOrderBasket: boolean
  showFavorites: boolean
  showProductDescriptions: boolean
}

// ── Restaurant ──────────────────────────────────────────────────────────
export interface RestaurantSettings {
  active: boolean
  subdomain: string
  customDomain: string
  seoTitle: Translation
  seoDescription: Translation
  currency: string
  /** Optional service/tax percentage (0 = none). */
  servicePercent: number
}

export interface Restaurant {
  id: string
  name: string
  slug: string
  /** The public theme this restaurant renders with. */
  themeId: ThemeId
  logo: string
  coverImage: string
  tagline: Translation
  /** Simple free-text address (v1; no maps/coordinates). */
  address: string
  workingHours: string
  rating: number
  /** Guest Wi-Fi, shown on the public menu (all plans). Empty = hidden. */
  wifiName: string
  wifiPassword: string
  defaultLanguage: LangCode
  activeLanguages: LangCode[]
  /** Subscription tier (set by super-admin). Gates paid features like AI. */
  planKey?: PlanKey
  /** Plan limits (null = unlimited). Mirrored from the backend plan. */
  maxProducts?: number | null
  maxCategories?: number | null
  /** Ordering/cart enabled (paid plans only). Public feature flag. */
  ordering?: boolean
  /** Cart display settings (paid plans). */
  showCartTotal?: boolean
  serviceChargeEnabled?: boolean
  serviceChargeMode?: 'percent' | 'text'
  serviceChargePercent?: number
}

export type PlanKey = 'free' | 'pro' | 'business'

// ── Service result envelope (mirrors a typical API response) ──────────────
export interface ApiList<T> {
  data: T[]
  total: number
}
