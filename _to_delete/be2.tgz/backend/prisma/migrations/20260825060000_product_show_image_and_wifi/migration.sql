-- Per-dish "show a picture" switch, plus the guest Wi-Fi columns that were
-- added to schema.prisma earlier without a migration of their own.
--
-- Every statement is IF NOT EXISTS so this is safe to run on a database that
-- already received any of these columns through `prisma db push`.

-- Products: does this dish show a picture on the public menu?
-- Defaults to true so every existing dish keeps behaving exactly as before.
ALTER TABLE "products"
  ADD COLUMN IF NOT EXISTS "showImage" BOOLEAN NOT NULL DEFAULT true;

-- Restaurants: guest Wi-Fi shown on the public menu (both optional).
ALTER TABLE "restaurants"
  ADD COLUMN IF NOT EXISTS "wifiName" TEXT;

ALTER TABLE "restaurants"
  ADD COLUMN IF NOT EXISTS "wifiPassword" TEXT;
