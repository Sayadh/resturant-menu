<script setup lang="ts">
// ─────────────────────────────────────────────────────────────────────────
// OpalineHero — the arrival plate. The house name set large in the editorial
// serif, a short line of description beneath it, then a quiet meta row.
//
// Every line is rendered ONLY when the tenant has actually filled it in from
// the admin panel — no placeholder copy is ever invented here. On phones the
// plate stays short on purpose so the first section card is already in view.
// ─────────────────────────────────────────────────────────────────────────
const { t } = useLanguage()
const brand = useBrand()

const tagline = computed(() => t(brand.tagline).trim())
const rating = computed(() => (brand.rating ? Number(brand.rating) : 0))
const hasMeta = computed(() => !!rating.value || !!brand.address)
</script>

<template>
  <section class="mx-auto max-w-3xl px-5 pb-9 pt-9 text-center sm:px-8 sm:pb-14 sm:pt-16">
    <h1
      v-if="brand.name"
      class="op-serif text-balance text-[clamp(2rem,8.5vw,3.5rem)] leading-[1.08] text-[#172033]"
    >
      {{ brand.name }}
    </h1>

    <p
      v-if="tagline"
      class="op-sans mx-auto mt-4 max-w-lg text-balance text-[15px] leading-relaxed text-[#747D90] sm:mt-5 sm:text-base"
    >
      {{ tagline }}
    </p>

    <template v-if="hasMeta">
      <div class="op-rule-soft mx-auto mt-6 w-20 sm:mt-8" aria-hidden="true" />

      <div
        class="op-sans mt-4 flex flex-wrap items-center justify-center gap-x-4 gap-y-2 text-[13px] text-[#747D90] sm:mt-5"
      >
        <span v-if="rating" class="inline-flex items-center gap-1.5">
          <svg viewBox="0 0 24 24" class="h-[15px] w-[15px] fill-[#D85F3D]" aria-hidden="true">
            <path d="M12 2.6l2.85 5.98 6.55.9-4.79 4.5 1.19 6.42L12 17.4l-5.8 3l1.19-6.42-4.79-4.5 6.55-.9z" />
          </svg>
          <span class="op-figure font-medium text-[#172033]">{{ rating }}</span>
        </span>

        <span v-if="rating && brand.address" class="h-3 w-px bg-[#E2E5E8]" aria-hidden="true" />

        <span v-if="brand.address" class="inline-flex items-center gap-1.5">
          <svg
            viewBox="0 0 24 24"
            class="h-[15px] w-[15px] text-[#A1A6B0]"
            fill="none"
            stroke="currentColor"
            stroke-width="1.5"
            stroke-linecap="round"
            stroke-linejoin="round"
            aria-hidden="true"
          >
            <path d="M12 21s-6.5-5.6-6.5-10.2A6.5 6.5 0 0 1 12 4.3a6.5 6.5 0 0 1 6.5 6.5C18.5 15.4 12 21 12 21z" />
            <circle cx="12" cy="10.6" r="2.3" />
          </svg>
          <span>{{ brand.address }}</span>
        </span>
      </div>
    </template>
  </section>
</template>
