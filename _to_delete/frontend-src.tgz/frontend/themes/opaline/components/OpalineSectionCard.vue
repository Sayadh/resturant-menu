<script setup lang="ts">
// ─────────────────────────────────────────────────────────────────────────
// OpalineSectionCard — a top-level section on the home screen: a large
// natural photograph on paper, the section name in the editorial serif, and
// a quiet count. Purely presentational; the parent owns navigation.
// ─────────────────────────────────────────────────────────────────────────
defineProps<{
  title: string
  image: string
  icon: string
  count: number
  countLabel: string
}>()

const emit = defineEmits<{ open: [] }>()
</script>

<template>
  <button
    type="button"
    class="group block w-full overflow-hidden rounded-[20px] border border-[#E2E5E8] bg-[#FFFFFF] text-left shadow-[0_1px_2px_rgba(23,32,51,0.04)] transition duration-300 hover:border-[#CCD1D7] hover:shadow-[0_18px_40px_-24px_rgba(23,32,51,0.28)] focus-visible:outline focus-visible:outline-1 focus-visible:outline-offset-2 focus-visible:outline-[#D85F3D] active:scale-[0.995]"
    @click="emit('open')"
  >
    <!-- Photograph — never tinted or filtered -->
    <div class="relative aspect-[16/10] w-full overflow-hidden bg-[#F5F5F2]">
      <img
        v-if="image"
        :src="image"
        alt=""
        loading="lazy"
        class="h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.035]"
      />
      <span
        v-else
        class="grid h-full w-full place-items-center bg-[#FBEDE8] text-4xl sm:text-5xl"
        aria-hidden="true"
      >{{ icon }}</span>
    </div>

    <div class="flex items-end justify-between gap-4 p-5 sm:p-6">
      <div class="min-w-0">
        <h3 class="op-serif truncate text-[22px] leading-tight text-[#172033] sm:text-[26px]">
          {{ title }}
        </h3>
        <p v-if="count" class="op-sans mt-1.5 text-[12px] text-[#747D90]">
          <span class="op-figure">{{ count }}</span> {{ countLabel }}
        </p>
      </div>

      <span
        class="grid h-9 w-9 shrink-0 place-items-center rounded-full border border-[#E2E5E8] text-[#747D90] transition-colors duration-300 group-hover:border-[#D85F3D] group-hover:bg-[#FBEDE8] group-hover:text-[#D85F3D]"
        aria-hidden="true"
      >
        <svg viewBox="0 0 24 24" class="h-4 w-4" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
          <path d="M5 12h13M13 6l6 6-6 6" />
        </svg>
      </span>
    </div>
  </button>
</template>
