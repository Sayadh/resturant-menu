<script setup lang="ts">
// ─────────────────────────────────────────────────────────────────────────
// OpalineBasketBar — a slim ink pill docked at the bottom of the screen once
// the guest has chosen something. Sits above the device safe area so it never
// collides with the home indicator.
// ─────────────────────────────────────────────────────────────────────────
import { ui } from '~/data/menu'
import { opalineOrder } from '~/themes/opaline/config'

const emit = defineEmits<{ open: [] }>()

const { t } = useLanguage()
const order = useOrderStore()
const brand = useBrand()
const menu = useMenuStore()

// Total is derived from the same store data the drawer uses — no duplicate
// pricing logic, and it honours the tenant's "hide total" setting.
const subtotal = computed(() =>
  order.lines.reduce((sum, l) => sum + (menu.findItem(l.id)?.item.price ?? 0) * l.qty, 0),
)
const fmt = (n: number) => n.toLocaleString('hy-AM')
</script>

<template>
  <ClientOnly>
    <Transition name="op-dock">
      <div
        v-if="order.count > 0"
        class="op-safe-b pointer-events-none fixed inset-x-0 bottom-0 z-40 flex justify-center px-4 pb-4 sm:pb-6"
      >
        <button
          type="button"
          class="pointer-events-auto flex w-full max-w-md items-center justify-between gap-4 rounded-full bg-[#172033] py-3 pl-5 pr-3 text-left shadow-[0_20px_44px_-18px_rgba(23,32,51,0.55)] transition hover:bg-[#222D43] active:scale-[0.985] focus-visible:outline focus-visible:outline-1 focus-visible:outline-offset-2 focus-visible:outline-[#D85F3D]"
          @click="emit('open')"
        >
          <span class="flex min-w-0 items-center gap-3">
            <span
              class="op-figure grid h-7 w-7 shrink-0 place-items-center rounded-full bg-[#D85F3D] text-[12px] font-semibold text-[#FFFFFF]"
              aria-hidden="true"
            >{{ order.count }}</span>
            <span class="op-label truncate text-[10px] text-[#FFFFFF]">{{ t(opalineOrder.view) }}</span>
          </span>

          <span
            v-if="brand.showCartTotal"
            class="op-figure op-sans shrink-0 rounded-full bg-[#FFFFFF]/10 px-3.5 py-1.5 text-[13px] font-medium text-[#FFFFFF]"
          >{{ fmt(subtotal) }} {{ ui.currency.AM }}</span>
          <span
            v-else
            class="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-[#FFFFFF]/10 text-[#FFFFFF]"
            aria-hidden="true"
          >
            <svg viewBox="0 0 24 24" class="h-4 w-4" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
              <path d="M9 5l7 7-7 7" />
            </svg>
          </span>
        </button>
      </div>
    </Transition>
  </ClientOnly>
</template>
