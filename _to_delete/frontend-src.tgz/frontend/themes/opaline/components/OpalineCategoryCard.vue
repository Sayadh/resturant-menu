<script setup lang="ts">
// ─────────────────────────────────────────────────────────────────────────
// OpalineCategoryCard — the second level. Deliberately NOT the section grid
// repeated: a compact editorial row on paper, separated by hairlines, with a
// medium photograph, the name in serif and one quiet line of context.
// Purely presentational; the parent owns navigation.
// ─────────────────────────────────────────────────────────────────────────
defineProps<{
  title: string
  description: string
  image: string
  icon: string
  count: number
  countLabel: string
}>()

const emit = defineEmits<{ open: [] }>()
</script>

<template>
  <button
    type="button"
    class="group flex w-full items-center gap-4 py-4 text-left transition-colors focus-visible:outline focus-visible:outline-1 focus-visible:outline-offset-2 focus-visible:outline-[#D85F3D] sm:gap-6 sm:py-5"
    @click="emit('open')"
  >
    <!-- Photograph — never tinted or filtered -->
    <span class="relative block h-[86px] w-[86px] shrink-0 overflow-hidden rounded-[14px] bg-[#F5F5F2] sm:h-[104px] sm:w-[104px]">
      <img
        v-if="image"
        :src="image"
        alt=""
        loading="lazy"
        class="h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.05]"
      />
      <span v-else class="grid h-full w-full place-items-center bg-[#FBEDE8] text-2xl sm:text-3xl" aria-hidden="true">{{ icon }}</span>
    </span>

    <span class="min-w-0 flex-1">
      <span class="op-serif block text-balance text-[19px] leading-snug text-[#172033] transition-colors duration-300 group-hover:text-[#D85F3D] sm:text-[23px]">
        {{ title }}
      </span>
      <span
        v-if="description"
        class="op-sans op-clamp-2 mt-1.5 block text-[13px] leading-relaxed text-[#747D90]"
      >{{ description }}</span>
      <span v-if="count" class="op-sans mt-1.5 block text-[12px] text-[#A1A6B0]">
        <span class="op-figure">{{ count }}</span> {{ countLabel }}
      </span>
    </span>

    <span
      class="shrink-0 text-[#CCD1D7] transition-all duration-300 group-hover:translate-x-0.5 group-hover:text-[#D85F3D]"
      aria-hidden="true"
    >
      <svg viewBox="0 0 24 24" class="h-5 w-5" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round">
        <path d="M9 5l7 7-7 7" />
      </svg>
    </span>
  </button>
</template>
