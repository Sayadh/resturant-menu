<script setup lang="ts">
// ─────────────────────────────────────────────────────────────────────────
// OpalinePageHead — the head of a section or category screen: the back
// action, an optional parent note (the section a category belongs to), the
// title in the editorial serif, and the description when the tenant wrote
// one. Not sticky on purpose — only the header pins, so nothing ever covers
// the content on small screens.
// ─────────────────────────────────────────────────────────────────────────
import { opalineBack } from '~/themes/opaline/config'

defineProps<{
  /** Small parent note above the title (e.g. the section name). */
  eyebrow?: string
  title: string
  description?: string
}>()

const emit = defineEmits<{ back: [] }>()

const { t } = useLanguage()
</script>

<template>
  <div class="pb-6 pt-5 sm:pb-8 sm:pt-7">
    <button
      type="button"
      class="op-label group -ml-2 inline-flex items-center gap-2 rounded-[10px] px-2 py-1.5 text-[10px] text-[#747D90] transition-colors hover:text-[#172033] focus-visible:outline focus-visible:outline-1 focus-visible:outline-offset-2 focus-visible:outline-[#D85F3D]"
      @click="emit('back')"
    >
      <svg
        viewBox="0 0 24 24"
        class="h-4 w-4 transition-transform duration-300 group-hover:-translate-x-0.5"
        fill="none"
        stroke="currentColor"
        stroke-width="1.6"
        stroke-linecap="round"
        stroke-linejoin="round"
        aria-hidden="true"
      >
        <path d="M15 5l-7 7 7 7" />
      </svg>
      {{ t(opalineBack) }}
    </button>

    <p v-if="eyebrow" class="op-label mt-5 text-[10px] text-[#D85F3D]">{{ eyebrow }}</p>

    <h1
      class="op-serif text-balance text-[28px] leading-[1.12] text-[#172033] sm:text-[40px]"
      :class="eyebrow ? 'mt-2' : 'mt-5'"
    >
      {{ title }}
    </h1>

    <p
      v-if="description"
      class="op-sans mt-3 max-w-xl text-[14px] leading-relaxed text-[#747D90] sm:mt-4 sm:text-[15px]"
    >
      {{ description }}
    </p>
  </div>
</template>
