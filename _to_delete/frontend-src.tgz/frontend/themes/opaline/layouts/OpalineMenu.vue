<script setup lang="ts">
// ─────────────────────────────────────────────────────────────────────────
// Opaline — root layout
//
// Opaline presents the menu as a guided journey instead of one long scroll:
//
//     Home (sections) → Section (categories) → Category (dishes)
//
// The level is held in the URL query of the EXISTING tenant route
// (`/<slug>?s=<sectionId>&c=<categoryId>`), so the restaurant slug, the domain
// resolver, the locale and the URL convention are all untouched, while browser
// back/forward, refresh and pasted deep links all work. Unknown ids simply
// fall back to the nearest valid level.
//
// All menu DATA, language, search, favourite, cart and order LOGIC come from
// the shared stores and composables — exactly like Aria, Atelier, Maison,
// Heritage and Noir. Only the presentation differs.
// ─────────────────────────────────────────────────────────────────────────
import { ui, type MenuCategory, type MenuItem, type MenuLevel } from '~/data/menu'
import {
  opalineCategoriesLabel,
  opalineCategoryCount,
  opalineEmpty,
  opalineSectionsLabel,
} from '~/themes/opaline/config'
import { vReveal } from '~/themes/opaline/animations'
import '~/themes/opaline/styles/opaline.css'

import OpalineHeader from '../components/OpalineHeader.vue'
import OpalineHero from '../components/OpalineHero.vue'
import OpalineSearch from '../components/OpalineSearch.vue'
import OpalineSectionCard from '../components/OpalineSectionCard.vue'
import OpalineCategoryCard from '../components/OpalineCategoryCard.vue'
import OpalinePageHead from '../components/OpalinePageHead.vue'
import OpalineProductCard from '../components/OpalineProductCard.vue'
import OpalineProductDetail from '../components/OpalineProductDetail.vue'
import OpalineBasketBar from '../components/OpalineBasketBar.vue'
import OpalineOrderDrawer from '../components/OpalineOrderDrawer.vue'
import OpalineEmpty from '../components/OpalineEmpty.vue'
import OpalineFooter from '../components/OpalineFooter.vue'

const route = useRoute()
const router = useRouter()

const { t } = useLanguage()
const store = useMenuStore()
const order = useOrderStore()
const brand = useBrand() // ordering (cart) = paid plans only

// ── level state, read straight from the URL ──────────────────────────────
const sectionId = computed(() => String(route.query.s || ''))
const categoryId = computed(() => String(route.query.c || ''))

/** Categories of a section that actually have something to show. */
const categoriesIn = (levelId: string): MenuCategory[] =>
  store.categoriesOf(levelId).filter((c) => c.items.length > 0)

/** Sections come from the API (`store.levels`) — never hardcoded. */
const sections = computed<MenuLevel[]>(() =>
  store.levels.filter((l) => categoriesIn(l.id).length > 0),
)

const activeSection = computed<MenuLevel | null>(
  () => sections.value.find((l) => l.id === sectionId.value) ?? null,
)
const sectionCategories = computed<MenuCategory[]>(() =>
  activeSection.value ? categoriesIn(activeSection.value.id) : [],
)
const activeCategory = computed<MenuCategory | null>(
  () => sectionCategories.value.find((c) => c.id === categoryId.value) ?? null,
)

const level = computed<'home' | 'section' | 'category'>(() =>
  activeCategory.value ? 'category' : activeSection.value ? 'section' : 'home',
)
const viewKey = computed(() => `${level.value}:${sectionId.value}:${categoryId.value}`)

// ── navigation (query-only; every other query param is preserved) ─────────
const navigate = (patch: Record<string, string | undefined>) => {
  const query: Record<string, unknown> = { ...route.query, ...patch }
  for (const key of Object.keys(query)) {
    if (query[key] === undefined) delete query[key]
  }
  router.push({ query })
}

const goHome = () => {
  search.value = ''
  navigate({ s: undefined, c: undefined })
}
const openSection = (id: string) => {
  search.value = ''
  navigate({ s: id, c: undefined })
}
const openCategory = (id: string) => navigate({ c: id })
const goBack = () => (level.value === 'category' ? navigate({ c: undefined }) : goHome())

// Each level starts at the top — including on browser back/forward.
watch(viewKey, () => {
  if (import.meta.client) window.scrollTo({ top: 0, behavior: 'auto' })
})

// ── search (same filter the other themes run, over the same store data) ───
const search = ref('')
const isSearching = computed(() => search.value.trim().length > 0)
const searchResults = computed<MenuCategory[]>(() => {
  const q = search.value.trim().toLowerCase()
  if (!q) return []
  return store.categories
    .map((cat) => ({
      ...cat,
      items: cat.items.filter((item) =>
        [
          item.name.AM,
          item.name.EN,
          item.name.RU,
          item.description.AM,
          item.description.EN,
          item.description.RU,
        ]
          .join(' ')
          .toLowerCase()
          .includes(q),
      ),
    }))
    .filter((cat) => cat.items.length > 0)
})

// ── derived presentation helpers ─────────────────────────────────────────
/** A section's picture: its own upload, else a category banner, else a dish. */
const sectionImage = (lvl: MenuLevel): string => {
  if (lvl.image) return lvl.image
  const cats = categoriesIn(lvl.id)
  const banner = cats.find((c) => c.image)?.image
  if (banner) return banner
  for (const c of cats) {
    const withPhoto = c.items.find((i) => i.image)
    if (withPhoto) return withPhoto.image
  }
  return ''
}

/** A category's picture: its own banner/icon upload, else one of its dishes. */
const categoryImage = (cat: MenuCategory): string =>
  cat.image || cat.iconImage || cat.items.find((i) => i.image)?.image || ''

const categoryDescription = (cat: MenuCategory): string =>
  cat.description ? t(cat.description).trim() : ''

const sectionCategoryCount = (lvl: MenuLevel) => categoriesIn(lvl.id).length

// ── product detail + order overlays ──────────────────────────────────────
const selected = ref<MenuItem | null>(null)
const orderOpen = ref(false)

onMounted(() => {
  // Defensive: clear any body scroll-lock a previous overlay/theme may have left.
  if (import.meta.client) document.body.style.overflow = ''
})

// Opaline owns its typography. Loaded here (not globally) so the marketing
// pages and the other themes are unaffected.
useHead({
  link: [
    { rel: 'preconnect', href: 'https://fonts.googleapis.com' },
    { rel: 'preconnect', href: 'https://fonts.gstatic.com', crossorigin: '' },
    {
      rel: 'stylesheet',
      href: 'https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,500;0,600;1,400&family=Inter:wght@400;500;600&family=Noto+Serif+Armenian:wght@400;500;600&family=Noto+Sans+Armenian:wght@400;500;600&display=swap',
    },
  ],
})
</script>

<template>
  <div class="opaline-theme flex min-h-screen flex-col">
    <OpalineHeader @home="goHome" />

    <main class="flex-1">
      <Transition name="op-page" mode="out-in">
        <div :key="viewKey">
          <!-- ─────────────── 1 · Home: the sections ─────────────── -->
          <template v-if="level === 'home'">
            <OpalineHero />

            <div class="mx-auto max-w-6xl px-5 sm:px-8">
              <OpalineSearch v-model="search" />
            </div>

            <!-- Search results (flat, across the whole menu) -->
            <section v-if="isSearching" class="mx-auto max-w-6xl px-5 pb-16 pt-10 sm:px-8 sm:pb-24 sm:pt-14">
              <template v-if="searchResults.length">
                <div v-for="cat in searchResults" :key="cat.id" class="mb-12 last:mb-0">
                  <h2 class="op-serif border-b border-[#E2E5E8] pb-3 text-[20px] text-[#172033] sm:text-[24px]">
                    {{ t(cat.title) }}
                  </h2>
                  <div class="mt-6 grid grid-cols-1 gap-5 sm:grid-cols-2 sm:gap-6 lg:grid-cols-3">
                    <OpalineProductCard
                      v-for="item in cat.items"
                      :key="item.id"
                      :item="item"
                      @open="selected = $event"
                    />
                  </div>
                </div>
              </template>
              <OpalineEmpty v-else :message="t(ui.noResults)" />
            </section>

            <!-- The sections themselves -->
            <section v-else class="mx-auto max-w-6xl px-5 pb-16 pt-10 sm:px-8 sm:pb-24 sm:pt-14">
              <template v-if="sections.length">
                <p v-reveal class="op-label text-center text-[10px] text-[#D85F3D]">
                  {{ t(opalineSectionsLabel) }}
                </p>

                <div class="mt-7 grid grid-cols-1 gap-5 sm:mt-10 sm:grid-cols-2 sm:gap-6">
                  <OpalineSectionCard
                    v-for="(lvl, i) in sections"
                    :key="lvl.id"
                    v-reveal="i"
                    :title="t(lvl.title)"
                    :image="sectionImage(lvl)"
                    :icon="lvl.icon"
                    :count="sectionCategoryCount(lvl)"
                    :count-label="t(opalineCategoryCount)"
                    @open="openSection(lvl.id)"
                  />
                </div>
              </template>

              <OpalineEmpty v-else :message="t(opalineEmpty.sections)" />
            </section>
          </template>

          <!-- ────────────── 2 · Section: its categories ────────────── -->
          <template v-else-if="level === 'section' && activeSection">
            <section class="mx-auto max-w-3xl px-5 pb-16 sm:px-8 sm:pb-24">
              <OpalinePageHead :title="t(activeSection.title)" @back="goBack" />

              <template v-if="sectionCategories.length">
                <p class="op-label border-t border-[#E2E5E8] pt-6 text-[10px] text-[#A1A6B0]">
                  {{ t(opalineCategoriesLabel) }}
                </p>

                <div class="mt-1 divide-y divide-[#E2E5E8]">
                  <OpalineCategoryCard
                    v-for="(cat, i) in sectionCategories"
                    :key="cat.id"
                    v-reveal="i"
                    :title="t(cat.title)"
                    :description="categoryDescription(cat)"
                    :image="categoryImage(cat)"
                    :icon="cat.icon"
                    :count="cat.items.length"
                    :count-label="t(ui.dishCount)"
                    @open="openCategory(cat.id)"
                  />
                </div>
              </template>

              <OpalineEmpty v-else :message="t(opalineEmpty.categories)" />
            </section>
          </template>

          <!-- ────────────── 3 · Category: its dishes ────────────── -->
          <template v-else-if="level === 'category' && activeCategory && activeSection">
            <section class="mx-auto max-w-6xl px-5 pb-16 sm:px-8 sm:pb-24">
              <OpalinePageHead
                :eyebrow="t(activeSection.title)"
                :title="t(activeCategory.title)"
                :description="categoryDescription(activeCategory)"
                @back="goBack"
              />

              <template v-if="activeCategory.items.length">
                <div class="grid grid-cols-1 gap-5 border-t border-[#E2E5E8] pt-8 sm:grid-cols-2 sm:gap-6 lg:grid-cols-3">
                  <OpalineProductCard
                    v-for="(item, i) in activeCategory.items"
                    :key="item.id"
                    v-reveal="i"
                    :item="item"
                    @open="selected = $event"
                  />
                </div>
              </template>

              <OpalineEmpty v-else :message="t(opalineEmpty.products)" />
            </section>
          </template>
        </div>
      </Transition>
    </main>

    <OpalineFooter />

    <!-- Keeps the floating order dock from ever covering the last line -->
    <ClientOnly>
      <div v-if="brand.ordering && order.count > 0" class="h-20 bg-[#F5F5F2]" aria-hidden="true" />
    </ClientOnly>

    <!-- Overlays -->
    <OpalineProductDetail :item="selected" @close="selected = null" />
    <OpalineBasketBar v-if="brand.ordering" @open="orderOpen = true" />
    <OpalineOrderDrawer v-if="brand.ordering" :open="orderOpen" @close="orderOpen = false" />
    <WifiButton theme="opaline" />
  </div>
</template>
